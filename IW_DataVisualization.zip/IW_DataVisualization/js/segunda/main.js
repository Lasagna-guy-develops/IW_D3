let data, scatterplot, barchart;
let filtroTratamiento = [];
console.log(document.getElementById('cuerpecito').children)

d3.csv('../../data/Datos_Longitudinales.csv')
  .then(_data => {
    data = _data;
    console.log(data)

    // Initialize scales
    const colorScale = d3.scaleOrdinal()
        .range(['#d3eecd', '#7bc77e', '#2a8d46']) // light green to dark green
        .domain(['1','2','3']);
    
    scatterplot = new Scatterplot({ 
      parentElement: '#scatterplot',
      colorScale: colorScale
    }, data);
    scatterplot.updateVis();

    barchart = new Barchart({
      parentElement: '#barchart',
      colorScale: colorScale
    }, data);
    barchart.updateVis();
  })

function filterData() {
  if (filtroTratamiento.length == 0) {
    scatterplot.data = data;
  } else {
    scatterplot.data = data.filter(d => filtroTratamiento.includes(d.Tratamiento));
  }
  scatterplot.updateVis();
}